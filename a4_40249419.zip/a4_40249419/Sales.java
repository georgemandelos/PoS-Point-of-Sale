// -------------------------------------------------------
// Assignment {2}
// Written by: {George Mandelos 40249419}
// For COMP 248 Section {P} – Fall 2023
// --------------------------------------------------------

//Hello User!

/* 
 */

public class Sales {

	private int junior; //create variables needed for class
	private int teen;
	private int medium;
	private int big;
	private int family;
	
	private final int juniorPrice = 5; //create variables needed for class
	private final int teenPrice = 10;
	private final int mediumPrice = 12;
	private final int bigPrice = 15;
	private final int familyPrice = 20;

	
	public Sales() { //default constructor
	}

	 public Sales(int junior, int teen, int medium, int big, int family) { // constructor with 5 integer parameters
		 this.junior = junior;
		 this.teen = teen;
		 this.medium = medium ;
		 this.big = big;
		 this.family = family;	 
	 }
	 
	 public Sales (Sales sales) { // copy constructor with 1 parameter to return a copy of the object
		 this.junior = sales.junior;
		 this.teen = sales.teen;
		 this.medium = sales.medium;
		 this.big = sales.big;
		 this.family = sales.family;
	 }
	 
	 
	 public void addSales(int j, int t, int m, int b, int f) { // method with 5 parameters to add sales to the pre-existing sales
		 this.junior += j;
		 this.teen += t;
		 this.medium += m;
		 this.big += b;
		 this.family += f;
	 }
	 
	 
	 public int SalesTotal() { // returns the total integer amount of money made from the sales
		 int total = junior * juniorPrice + teen * teenPrice + medium * mediumPrice + big * bigPrice + family * familyPrice;
		 return total;
	 }
	 
	
	 public String toString() { // returns the amount of sales per size and the price of the size in a string
		 String count;
		 count = (Integer.toString(junior) +" x $5 + " + Integer.toString(teen)+ " x $10 + " + Integer.toString(medium)+ " x $12 + " + Integer.toString(big) +" x $15 + "+ Integer.toString(family) + " x $20");
		 return count;
	 }
	 
	 
	 public boolean equals(Object s1) { // returns true if two sales have the same amount of sales
		
		if (this == s1) return true;
		if (s1 == null || getClass() != s1.getClass()) return false;
		 	Sales sales = (Sales) s1;
		 
		 	return junior == sales.junior && teen == sales.teen && medium == sales.medium && big == sales.big && family == sales.family;
	 }
}
