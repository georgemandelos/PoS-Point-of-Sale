// -------------------------------------------------------
// Assignment {2}
// Written by: {George Mandelos 40249419}
// For COMP 248 Section {P} – Fall 2023
// --------------------------------------------------------

//Hello User!

/* This program acts as the Point of Sale for costless bites. It does many things using static methods like displaying a singlePoS, displaying the contents of all the PoS's, displaying PoS's that have the same amount of sales, 
 * displaying the PoS's that have the same number of Sale types, displays the PoS's with the same number of prepaidcards and the same amount of dollars in sales, add a pre paid card and displays how many prepaidcardsthey now have, 
 * removing a prepaidcard and displays a message, updates expiry date of one of the prepaidcards in a certain PoS and prints a message, add sales to a PoS and display the new total amount of sales. The program displays a menu using
 * a static method and once the user picks the number the program runs the corresponding case in the switch statement.
 */
import java.util.Scanner;

public class PoSDemo {

	public static void main(String[] args) {
			
   	 System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"); // Display welcome message
   	 System.out.println("| Welcome to Concordia CostLessBites Catering Sales Counter Application        |");
   	 System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
   
       Scanner key = new Scanner(System.in);// create scanner
       
		Sales sale0 = new Sales(2, 1, 0, 4, 1); //create 5 objects of type Sales
		Sales sale1 = new Sales(2, 1, 0, 4, 1);
		Sales sale2 = new Sales(0, 1, 5, 2, 0);
		Sales sale3 = new Sales(3, 2, 4, 1, 2);
		Sales sale4 = new Sales(3, 2, 4, 1, 2);
	
		PrePaiCard prepai0[] = new PrePaiCard[2];//create 5 array objects of type PrePaiCard	
		prepai0[0] = new PrePaiCard("Vegetarian", "40825164", 25, 12);
		prepai0[1] = new PrePaiCard("Carnivore", "21703195", 3, 12);
		
		PrePaiCard[] prepai1 = new PrePaiCard[2];
		prepai1[0] = new PrePaiCard("Vigan", "40825164", 7, 12);
		prepai1[1] = new PrePaiCard("Vegetarian", "21596387", 24, 8);
		
		PrePaiCard[] prepai2 = new PrePaiCard[3];
		prepai2[0] = new PrePaiCard("Pescatarian", "95432806", 1, 6);
		prepai2[1] = new PrePaiCard("Halal", "42087913", 18, 12);
		prepai2[2] = new PrePaiCard("Kosher", "40735421", 05, 04);
		
		PrePaiCard[] prepai3 = new PrePaiCard[0];
		PrePaiCard[] prepai4 = new PrePaiCard[0];
	
		PoS[] pos = new PoS[5]; // create 5 PoS objects with the sales and prepaicard objects
		pos[0] = new PoS(sale0, prepai0);
		pos[1] = new PoS(sale1, prepai1);
		pos[2] = new PoS(sale2, prepai2);
		pos[3] = new PoS(sale3, prepai3);
		pos[4] = new PoS(sale4, prepai4);
    
       int choice;// int called choice to use in the do while loop and the switch statement
     
       do { // do-while loop that loops as long as the choice entered by the user does not equal 0
       	
           printMenu();// print the menu 
           
           System.out.print("\nPlease enter your choice and press <Enter>: ");// prompt the user to enter a choice 0-9
           
           choice = key.nextInt();// get choice
           
           switch (choice) { // Switch statement that uses the choice to conduct the operation
           
           case 1:
               displayAllPos(pos); // display all the PoS's
               break;
               
           case 2:
               displaySinglePos(pos, key);// display wanted output
               break;
               
           case 3:
               displayPosWithSameSales(pos); // display wanted output
               break;
               
           case 4:
               displayPosWithSameNum(pos); // display wanted output
               break;
               
           case 5:
               displayPosEquality(pos); // display wanted output
               break;
               
           case 6:
               addPrePaiCardToPos(pos, key); // display wanted output
               break;
               
           case 7:
               removePrePaiCardFromPos(pos, key); // display wanted output
               break;
           case 8:
               updateExpiryDate(pos, key); // display wanted output
               break;
               
           case 9:
               addSalesToPos(pos, key); // display wanted output
               break;
               
           case 0:
               System.out.println("Thank you for using Concordia CostLessBites Catering Sales Counter Application!");//thank you message 
               break;
               
           default:// if the user enters a number thats not 0-9 ask them try again
               System.out.println("Sorry that is not a valid choice. Try again.");
       }
           
       } while (choice != 0 ); // end the loop when count equals 0
   }

  

   private static void printMenu() { //print the menu
       System.out.println("| What would you like to do?                                                   |");
       System.out.println("| 1 >> See the content of all PoSs                                             |");
       System.out.println("| 2 >> See the content of one PoS                                              |");
       System.out.println("| 3 >> List PoSs with same $ amount of sales                                   |");
       System.out.println("| 4 >> List PoSs with same number of Sales categories                          |");
       System.out.println("| 5 >> List PoSs with same $ amount of Sales and same number of prepaid cards  |");
       System.out.println("| 6 >> Add a PrePaiCard to an existing PoS                                     |");
       System.out.println("| 7 >> Remove an existing prepaid card from a PoS                              |");
       System.out.println("| 8 >> Update the expiry date of an existing Prepaid card                      |");
       System.out.println("| 9 >> AddSalestoaPoS                                                          |");
       System.out.println("| 0 >> Toquit                                                                  |");
       System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
   }

   private static void displayAllPos(PoS[] pos) { // display all the PoS's
   	System.out.println("Content of each PoS: \n---------------------");
   	
       for (int i = 0; i < pos.length; i++) {
           System.out.println("PoS #" + i + ":\n" + pos[i].toString());
       }
   }

   private static void displaySinglePos(PoS[] pos, Scanner key) { // display a single PoS
       int k;
       System.out.print("Which PoS you want to see the content of? (Enter number 0 to 4): ");
       k = key.nextInt();
       
       while (k != 0 && k != 1 && k != 2 && k != 3 && k != 4) {
           System.out.println("Sorry but there is no PoS number " + k);
           System.out.print("--> Try again: (Enter number 0 to 4): ");
           k = key.nextInt();
       }
       System.out.println(pos[k].toString());
       System.out.println();
   }

   private static void displayPosWithSameSales(PoS[] pos) {// display PoS's with the same dollar amount of sales
       System.out.println("List of PoSs with same total $ Sales: \n");
       for (int i = 0; i < pos.length - 1; i++) {
           for (int j = i + 1; j < pos.length; j++) {
               if (pos[i].Salecomp(pos[j])) {
                   System.out.println("PoSs " + i + " and " + j + " both have " + pos[i].Tsales());
               }
           }
       } System.out.println();
   }

   private static void displayPosWithSameNum(PoS[] pos) {//display the the PoS's with the same number of sales sizes
   	System.out.println("List of PoSs with same Sales categories: \n");
   	
       for (int i = 0; i < pos.length - 1; i++) {
    	   
           for (int j = i + 1; j < pos.length; j++) {
               if (pos[i].Snumcomp(pos[j])) {
                   System.out.println("\tPoSs " + i + " and " + j + " both have " + pos[i].BSales());
               }
           }
       } 
       System.out.println();
   }

   private static void displayPosEquality(PoS[] pos) { // displays the PoS's with the same amount of prepaid cards and the total dollar amount of sales
   	System.out.println("List of PoSs with same $ amount of sales and same number of PrePaiCards :\n");
   	
       for (int i = 0; i < pos.length - 1; i++) {
    	   
           for (int j = i + 1; j < pos.length; j++) {
               if (pos[i].equals(pos[j])) {
                   System.out.println("\tPoSs " + i + " and " + j);
               }
           }
       } 
       System.out.println();
   }

   private static void addPrePaiCardToPos(PoS[] pos, Scanner key) {//adds a pre paid card to a PoS displays how many prepaidcards you now have in the PoS
	   
       System.out.print("Which PoS do you want to add a PrePaiCard to? (Enter number 0 to 4): ");
       int posIndex = key.nextInt();

       System.out.println("Please enter the following information to complete the PrePaiCard-");
       System.out.println("--> Type of PrePaiCard (Carnivore, Halal, Kosher, Pescatarian, Vegetarian, Vigan):");
       String cardType = key.next();

       System.out.print("--> Id of the prepaid card owner: ");
       String ownerId = key.next();

       System.out.print("--> Expiry day number and month (separate by a space): ");
       int day = key.nextInt();
       int month = key.nextInt();

       PrePaiCard prePaiCard = new PrePaiCard(cardType, ownerId, day, month);
       System.out.println(pos[posIndex].AddPPC(prePaiCard));
       System.out.println();
   }

   private static void removePrePaiCardFromPos(PoS[] pos, Scanner key) { //removes a prepaid card and displays whether it was removed successfully or not
	   
       System.out.print("Which PoS you want to remove an PrePaiCard from? (Enter number 0 to 4): ");
       int b4 = -1;
       int posIndex = key.nextInt();
       
       if (pos[posIndex].RemovePPC(b4) == false) {
           System.out.println("Sorry, that PoS has no PrePaiCards");
           return;
       }

       System.out.println("(Enter number 0 to 2):");
       int cardIndex = key.nextInt();

       System.out.println(pos[posIndex].RemovePPC(cardIndex) ? "PrePaiCard was removed successfully" : "Failed to remove PrePaiCard");
       System.out.println();
   }

   private static void updateExpiryDate(PoS[] pos, Scanner key) {//updates the expiry date of a prepaid card and displays the expiry date was updated
       System.out.print("Which PoS do you want to update a PrePaiCard's expiry date? (Enter number 0 to 4): ");
       int posIndex = key.nextInt();

       System.out.print("Which PrePaiCard do you want to update? (Enter number 0 to 2)" );
       int cardIndex = key.nextInt();

       System.out.print("--> Enter new expiry date day number and month (separate by a space): ");
       int day = key.nextInt();
       int month = key.nextInt();

       pos[posIndex].NExp(cardIndex, day, month);
       System.out.println("Expiry Date updated.");
       System.out.println();
   }

   private static void addSalesToPos(PoS[] pos, Scanner key) { //adds sales to the PoS of choice and shows the total amount the sales 
       System.out.print("Which PoS do you want to add Sales to? (Enter number 0 to 4): ");
       int posIndex = key.nextInt();

       System.out.print("How many junior, teen, medium, big, and family meal menu do you want to add? \n" + "Enter 5 numbers separated by a space): ");
       int junior = key.nextInt();
       int teen = key.nextInt();
       int medium = key.nextInt();
       int big = key.nextInt();
       int family = key.nextInt();

       System.out.println("You now have $" + (double) pos[posIndex].ASales(junior, teen, medium, big, family));
       System.out.println();
   

       key.close();
	}

}
