// -------------------------------------------------------
// Assignment {2}
// Written by: {George Mandelos 40249419}
// For COMP 248 Section {P} – Fall 2023
// --------------------------------------------------------

//Hello User!

/* 
 */

public class PoS {
	
		private Sales sales; // create two variables of type Sales and one array of type PrePaiCard that will be used in the class
		private PrePaiCard []PrePaiCards;
		
		public PoS() { // default constructor
			
		}
		
	
		public PoS(Sales sales, PrePaiCard []PrePaiCards) { // 2 parameters type Sales and type PrePaiCard
			this.sales = new Sales(sales);
		
			if (PrePaiCards != null) { // check if PrePaiCard is empty if it is not create an array of type PrePaiCard with it	
				this.PrePaiCards = new PrePaiCard[PrePaiCards.length];
				for (int i = 0; i < PrePaiCards.length; i++) {
					this.PrePaiCards[i] = new PrePaiCard(PrePaiCards[i]);
				}
			} 
				else {
					this.PrePaiCards = null;
				}
		}
	
		public boolean Salecomp(PoS other) { // returns true if two sales of different PoS objects have the same dollar amount of sales
			return (this.sales.SalesTotal() == other.sales.SalesTotal()) ;
		}

	
		public boolean Snumcomp(PoS other) {// returns true if two Sales of different PoS objects have the same amount of sales per size of food
			return this.sales.equals(other.sales);
		}
		
	
		public int Tsales() { // returns the int value of the total dollar amount of sales in the PoS
			return this.sales.SalesTotal();
		}
		
	
		public int NumPPC() { // returns the amount of pre paid cards in the PoS
			return (PrePaiCards != null && PrePaiCards.length != 0 )? PrePaiCards.length :0;
		}
		
	
		public String AddPPC(PrePaiCard nCard) {// String with parameter PrePaiCard that adds a prepaicard to the PoS and then returns a string showing how many prepaidcards they have
			String a;
			if (PrePaiCards == null || PrePaiCards.length == 0) {
				PrePaiCards = new PrePaiCard[] {nCard};
				a = "You now have 1 PrePaiCard";
			}
			else {
				PrePaiCard nArray[] = new PrePaiCard[PrePaiCards.length + 1];
				for (int i = 0; i<PrePaiCards.length;i++) {
					nArray[i] = PrePaiCards[i];
				}
				nArray[PrePaiCards.length] = new PrePaiCard(nCard);
				PrePaiCards = nArray;
				a = "You now have " + PrePaiCards.length + " PrePaiCards";
			}
			return a;
		}
		
	
		public boolean RemovePPC(int index) { // returns true after removing a prepaid card of the index in the parameter
			boolean a = false;
			if (PrePaiCards != null && index>= 0 && index<PrePaiCards.length) {
				PrePaiCard nArray[] = new PrePaiCard[PrePaiCards.length - 1];
				for (int i = 0, j = 0; i<PrePaiCards.length;i++) {
					if (index != i) { 
						nArray[j++] = PrePaiCards[i];
					}
			} 
				PrePaiCards = nArray;
				}
			
			if (PrePaiCards != null && PrePaiCards.length != 0) a = true;
			else a = false;
		    return a;
		}
		
	
		public void NExp(int index, int day, int month) { // 3 integer parameters that changes the expiry date of a prepaidcard
			PrePaiCards[index].setDay(day);
			PrePaiCards[index].setMonth(month);
			}
	
		public int ASales(int j, int t, int m, int b, int f) { // 5 integer parameters that add sales to the pre existing sales and returns the total dollar amount of the sales
			this.sales.addSales(j, t, m, b, f);
			return this.sales.SalesTotal();
			}
	
		public boolean equals(PoS other) { // returns true two objects of type PoS have the same dollar amount of sales and the same amount of prepaidcards
			return (sales.SalesTotal() == other.sales.SalesTotal()) && (other.PrePaiCards.length == PrePaiCards.length) ;
		}
	
		public String toString() { // returns the string of the sales and prepaidcards
			String a;
			if (PrePaiCards != null && PrePaiCards.length>0) {
				a = sales.toString() + "\n";
				for(int i=0; i<PrePaiCards.length; i++)
					a+= PrePaiCards[i].toString() + "\n";
			}
			else { 
			 a = (sales.toString() + "\n" + "No prepaid cards" + "\n");
				
			}
			return a;
		}
	
		public String BSales() { // returns the string of the sales 
			return sales.toString();
			
		}
}
