// -------------------------------------------------------
// Assignment {2}
// Written by: {George Mandelos 40249419}
// For COMP 248 Section {P} – Fall 2023
// --------------------------------------------------------

//Hello User!

/* 
 */

public class PrePaiCard {

		private String cardType; // create variables needed for class
		private String Id;
		private int expiryDay;
		private int expiryMonth;
	
		public PrePaiCard() { // default constructor
			
		}
	
		public PrePaiCard(String cardType, String Id, int expiryDay, int expiryMonth) { // 2 string parameters and 2 int parameters
			this.cardType = cardType;
			this.expiryDay = expiryDay;
			this.expiryMonth = expiryMonth;
			this.Id = Id;
		}
	
		public PrePaiCard(PrePaiCard other) { // copy constructor
			this.cardType = other.cardType;
			this.expiryDay = other.expiryDay;
			this.expiryMonth = other.expiryMonth;
			this.Id = other.Id;
		}
	
		public String getCard() { // accessor method for cardType
			return cardType;
		}
	
		public String getId() { // accessor method for Id
			return Id;
		}
	
		public void setDay(int expiryDay) { // 1 int parameter for Day
			this.expiryDay = (expiryDay > 0 && expiryDay < 32)? expiryDay: 0;
		}
	
		public void setMonth(int expiryMonth) { // 1 int parameter for Month
			this.expiryMonth = (expiryMonth > 0 && expiryMonth < 13)? expiryMonth: 0;
		}
	
		public int getDay() { // acsessor method for day
			return expiryDay;
		}
	
		public int getMonth() { // accessor method for month
			return expiryMonth;
		}
	
		public String toString() { // return the cardtype id and expiry date in a string 
			return this.cardType + "-" + this.Id + "-" +((this.expiryDay<10) ? ("0"+this.expiryDay) : (this.expiryDay)) + "/" + ((this.expiryMonth<10) ? ("0"+this.expiryMonth) : (this.expiryMonth));
		}
	
		public boolean equals(Object s1) { // returns true if two objects of the class PrePaiCard are of the same makeup
			if (this == s1) return true;
			if (s1 == null || getClass() != s1.getClass()) return false;
			 PrePaiCard other = (PrePaiCard) s1;
			 return other.Id == Id && other.expiryDay == expiryDay && other.expiryMonth == expiryMonth && other.cardType.equals(cardType);
		}
}
